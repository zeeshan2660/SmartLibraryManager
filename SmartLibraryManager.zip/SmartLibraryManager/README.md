# Smart Library Manager (Java Project)

A simple and impressive Java console project using:
- OOP Concepts
- Classes & Objects
- Encapsulation
- ArrayList
- File Structure
- User Input
- Searching System

## Features
✔ Add Books  
✔ Show All Books  
✔ Issue Books  
✔ Return Books  
✔ Search Books  

## Technologies Used
- Java
- VS Code / IntelliJ IDEA

## How to Run

1. Open project in VS Code
2. Compile files:

```bash
javac src/*.java
```

3. Run project:

```bash
java -cp src Main
```

## Author
Zeeshan Sheikh
